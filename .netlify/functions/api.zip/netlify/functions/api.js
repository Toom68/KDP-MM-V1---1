"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/api.mjs
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
var import_node_crypto2 = __toESM(require("crypto"), 1);

// node_modules/@netlify/blobs/dist/chunk-XR3MUBBK.js
var NF_ERROR = "x-nf-error";
var NF_REQUEST_ID = "x-nf-request-id";
var BlobsInternalError = class extends Error {
  constructor(res) {
    let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
    if (res.headers.has(NF_REQUEST_ID)) {
      details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
    }
    super(`Netlify Blobs has generated an internal error (${details})`);
    this.name = "BlobsInternalError";
  }
};
var collectIterator = async (iterator) => {
  const result = [];
  for await (const item of iterator) {
    result.push(item);
  }
  return result;
};
var base64Decode = (input) => {
  const { Buffer: Buffer2 } = globalThis;
  if (Buffer2) {
    return Buffer2.from(input, "base64").toString();
  }
  return atob(input);
};
var base64Encode = (input) => {
  const { Buffer: Buffer2 } = globalThis;
  if (Buffer2) {
    return Buffer2.from(input).toString("base64");
  }
  return btoa(input);
};
var getEnvironment = () => {
  const { Deno, Netlify, process: process2 } = globalThis;
  return Netlify?.env ?? Deno?.env ?? {
    delete: (key) => delete process2?.env[key],
    get: (key) => process2?.env[key],
    has: (key) => Boolean(process2?.env[key]),
    set: (key, value) => {
      if (process2?.env) {
        process2.env[key] = value;
      }
    },
    toObject: () => process2?.env ?? {}
  };
};
var getEnvironmentContext = () => {
  const context = globalThis.netlifyBlobsContext || getEnvironment().get("NETLIFY_BLOBS_CONTEXT");
  if (typeof context !== "string" || !context) {
    return {};
  }
  const data = base64Decode(context);
  try {
    return JSON.parse(data);
  } catch {
  }
  return {};
};
var setEnvironmentContext = (context) => {
  const encodedContext = base64Encode(JSON.stringify(context));
  getEnvironment().set("NETLIFY_BLOBS_CONTEXT", encodedContext);
};
var MissingBlobsEnvironmentError = class extends Error {
  constructor(requiredProperties) {
    super(
      `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
        ", "
      )}`
    );
    this.name = "MissingBlobsEnvironmentError";
  }
};
var BASE64_PREFIX = "b64;";
var METADATA_HEADER_INTERNAL = "x-amz-meta-user";
var METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
var METADATA_MAX_SIZE = 2 * 1024;
var encodeMetadata = (metadata) => {
  if (!metadata) {
    return null;
  }
  const encodedObject = base64Encode(JSON.stringify(metadata));
  const payload = `b64;${encodedObject}`;
  if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
    throw new Error("Metadata object exceeds the maximum size");
  }
  return payload;
};
var decodeMetadata = (header) => {
  if (!header || !header.startsWith(BASE64_PREFIX)) {
    return {};
  }
  const encodedData = header.slice(BASE64_PREFIX.length);
  const decodedData = base64Decode(encodedData);
  const metadata = JSON.parse(decodedData);
  return metadata;
};
var getMetadataFromResponse = (response2) => {
  if (!response2.headers) {
    return {};
  }
  const value = response2.headers.get(METADATA_HEADER_EXTERNAL) || response2.headers.get(METADATA_HEADER_INTERNAL);
  try {
    return decodeMetadata(value);
  } catch {
    throw new Error(
      "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
    );
  }
};
var BlobsConsistencyError = class extends Error {
  constructor() {
    super(
      `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
    );
    this.name = "BlobsConsistencyError";
  }
};
var regions = {
  "us-east-1": true,
  "us-east-2": true,
  "eu-central-1": true,
  "ap-southeast-1": true,
  "ap-southeast-2": true
};
var isValidRegion = (input) => Object.keys(regions).includes(input);
var InvalidBlobsRegionError = class extends Error {
  constructor(region) {
    super(
      `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
    );
    this.name = "InvalidBlobsRegionError";
  }
};
var DEFAULT_RETRY_DELAY = getEnvironment().get("NODE_ENV") === "test" ? 1 : 5e3;
var MIN_RETRY_DELAY = 1e3;
var MAX_RETRY = 5;
var RATE_LIMIT_HEADER = "X-RateLimit-Reset";
var fetchAndRetry = async (fetch2, url, options, attemptsLeft = MAX_RETRY) => {
  try {
    const res = await fetch2(url, options);
    if (attemptsLeft > 0 && (res.status === 429 || res.status >= 500)) {
      const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
      await sleep(delay);
      return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
    }
    return res;
  } catch (error) {
    if (attemptsLeft === 0) {
      throw error;
    }
    const delay = getDelay();
    await sleep(delay);
    return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
  }
};
var getDelay = (rateLimitReset) => {
  if (!rateLimitReset) {
    return DEFAULT_RETRY_DELAY;
  }
  return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
};
var sleep = (ms) => new Promise((resolve) => {
  setTimeout(resolve, ms);
});
var SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
var Client = class {
  constructor({ apiURL, consistency, edgeURL, fetch: fetch2, region, siteID, token, uncachedEdgeURL }) {
    this.apiURL = apiURL;
    this.consistency = consistency ?? "eventual";
    this.edgeURL = edgeURL;
    this.fetch = fetch2 ?? globalThis.fetch;
    this.region = region;
    this.siteID = siteID;
    this.token = token;
    this.uncachedEdgeURL = uncachedEdgeURL;
    if (!this.fetch) {
      throw new Error(
        "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
      );
    }
  }
  async getFinalRequest({
    consistency: opConsistency,
    key,
    metadata,
    method,
    parameters = {},
    storeName
  }) {
    const encodedMetadata = encodeMetadata(metadata);
    const consistency = opConsistency ?? this.consistency;
    let urlPath = `/${this.siteID}`;
    if (storeName) {
      urlPath += `/${storeName}`;
    }
    if (key) {
      urlPath += `/${key}`;
    }
    if (this.edgeURL) {
      if (consistency === "strong" && !this.uncachedEdgeURL) {
        throw new BlobsConsistencyError();
      }
      const headers = {
        authorization: `Bearer ${this.token}`
      };
      if (encodedMetadata) {
        headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
      }
      if (this.region) {
        urlPath = `/region:${this.region}${urlPath}`;
      }
      const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
      for (const key2 in parameters) {
        url2.searchParams.set(key2, parameters[key2]);
      }
      return {
        headers,
        url: url2.toString()
      };
    }
    const apiHeaders = { authorization: `Bearer ${this.token}` };
    const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
    for (const key2 in parameters) {
      url.searchParams.set(key2, parameters[key2]);
    }
    if (this.region) {
      url.searchParams.set("region", this.region);
    }
    if (storeName === void 0 || key === void 0) {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    if (encodedMetadata) {
      apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
    }
    if (method === "head" || method === "delete") {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    const res = await this.fetch(url.toString(), {
      headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
      method
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
    const { url: signedURL } = await res.json();
    const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
    return {
      headers: userHeaders,
      url: signedURL
    };
  }
  async makeRequest({
    body,
    consistency,
    headers: extraHeaders,
    key,
    metadata,
    method,
    parameters,
    storeName
  }) {
    const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
      consistency,
      key,
      metadata,
      method,
      parameters,
      storeName
    });
    const headers = {
      ...baseHeaders,
      ...extraHeaders
    };
    if (method === "put") {
      headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
    }
    const options = {
      body,
      headers,
      method
    };
    if (body instanceof ReadableStream) {
      options.duplex = "half";
    }
    return fetchAndRetry(this.fetch, url, options);
  }
};
var getClientOptions = (options, contextOverride) => {
  const context = contextOverride ?? getEnvironmentContext();
  const siteID = context.siteID ?? options.siteID;
  const token = context.token ?? options.token;
  if (!siteID || !token) {
    throw new MissingBlobsEnvironmentError(["siteID", "token"]);
  }
  if (options.region !== void 0 && !isValidRegion(options.region)) {
    throw new InvalidBlobsRegionError(options.region);
  }
  const clientOptions = {
    apiURL: context.apiURL ?? options.apiURL,
    consistency: options.consistency,
    edgeURL: context.edgeURL ?? options.edgeURL,
    fetch: options.fetch,
    region: options.region,
    siteID,
    token,
    uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
  };
  return clientOptions;
};

// node_modules/@netlify/blobs/dist/main.js
var connectLambda = (event) => {
  const rawData = base64Decode(event.blobs);
  const data = JSON.parse(rawData);
  const environmentContext = {
    deployID: event.headers["x-nf-deploy-id"],
    edgeURL: data.url,
    siteID: event.headers["x-nf-site-id"],
    token: data.token
  };
  setEnvironmentContext(environmentContext);
};
var DEPLOY_STORE_PREFIX = "deploy:";
var LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
var SITE_STORE_PREFIX = "site:";
var Store = class _Store {
  constructor(options) {
    this.client = options.client;
    if ("deployID" in options) {
      _Store.validateDeployID(options.deployID);
      let name = DEPLOY_STORE_PREFIX + options.deployID;
      if (options.name) {
        name += `:${options.name}`;
      }
      this.name = name;
    } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
      const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
      _Store.validateStoreName(storeName);
      this.name = storeName;
    } else {
      _Store.validateStoreName(options.name);
      this.name = SITE_STORE_PREFIX + options.name;
    }
  }
  async delete(key) {
    const res = await this.client.makeRequest({ key, method: "delete", storeName: this.name });
    if (![200, 204, 404].includes(res.status)) {
      throw new BlobsInternalError(res);
    }
  }
  async get(key, options) {
    const { consistency, type } = options ?? {};
    const res = await this.client.makeRequest({ consistency, key, method: "get", storeName: this.name });
    if (res.status === 404) {
      return null;
    }
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
    if (type === void 0 || type === "text") {
      return res.text();
    }
    if (type === "arrayBuffer") {
      return res.arrayBuffer();
    }
    if (type === "blob") {
      return res.blob();
    }
    if (type === "json") {
      return res.json();
    }
    if (type === "stream") {
      return res.body;
    }
    throw new BlobsInternalError(res);
  }
  async getMetadata(key, { consistency } = {}) {
    const res = await this.client.makeRequest({ consistency, key, method: "head", storeName: this.name });
    if (res.status === 404) {
      return null;
    }
    if (res.status !== 200 && res.status !== 304) {
      throw new BlobsInternalError(res);
    }
    const etag = res?.headers.get("etag") ?? void 0;
    const metadata = getMetadataFromResponse(res);
    const result = {
      etag,
      metadata
    };
    return result;
  }
  async getWithMetadata(key, options) {
    const { consistency, etag: requestETag, type } = options ?? {};
    const headers = requestETag ? { "if-none-match": requestETag } : void 0;
    const res = await this.client.makeRequest({
      consistency,
      headers,
      key,
      method: "get",
      storeName: this.name
    });
    if (res.status === 404) {
      return null;
    }
    if (res.status !== 200 && res.status !== 304) {
      throw new BlobsInternalError(res);
    }
    const responseETag = res?.headers.get("etag") ?? void 0;
    const metadata = getMetadataFromResponse(res);
    const result = {
      etag: responseETag,
      metadata
    };
    if (res.status === 304 && requestETag) {
      return { data: null, ...result };
    }
    if (type === void 0 || type === "text") {
      return { data: await res.text(), ...result };
    }
    if (type === "arrayBuffer") {
      return { data: await res.arrayBuffer(), ...result };
    }
    if (type === "blob") {
      return { data: await res.blob(), ...result };
    }
    if (type === "json") {
      return { data: await res.json(), ...result };
    }
    if (type === "stream") {
      return { data: res.body, ...result };
    }
    throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
  }
  list(options = {}) {
    const iterator = this.getListIterator(options);
    if (options.paginate) {
      return iterator;
    }
    return collectIterator(iterator).then(
      (items) => items.reduce(
        (acc, item) => ({
          blobs: [...acc.blobs, ...item.blobs],
          directories: [...acc.directories, ...item.directories]
        }),
        { blobs: [], directories: [] }
      )
    );
  }
  async set(key, data, { metadata } = {}) {
    _Store.validateKey(key);
    const res = await this.client.makeRequest({
      body: data,
      key,
      metadata,
      method: "put",
      storeName: this.name
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
  }
  async setJSON(key, data, { metadata } = {}) {
    _Store.validateKey(key);
    const payload = JSON.stringify(data);
    const headers = {
      "content-type": "application/json"
    };
    const res = await this.client.makeRequest({
      body: payload,
      headers,
      key,
      metadata,
      method: "put",
      storeName: this.name
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
  }
  static formatListResultBlob(result) {
    if (!result.key) {
      return null;
    }
    return {
      etag: result.etag,
      key: result.key
    };
  }
  static validateKey(key) {
    if (key === "") {
      throw new Error("Blob key must not be empty.");
    }
    if (key.startsWith("/") || key.startsWith("%2F")) {
      throw new Error("Blob key must not start with forward slash (/).");
    }
    if (new TextEncoder().encode(key).length > 600) {
      throw new Error(
        "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
      );
    }
  }
  static validateDeployID(deployID) {
    if (!/^\w{1,24}$/.test(deployID)) {
      throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
    }
  }
  static validateStoreName(name) {
    if (name.includes("/") || name.includes("%2F")) {
      throw new Error("Store name must not contain forward slashes (/).");
    }
    if (new TextEncoder().encode(name).length > 64) {
      throw new Error(
        "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
      );
    }
  }
  getListIterator(options) {
    const { client, name: storeName } = this;
    const parameters = {};
    if (options?.prefix) {
      parameters.prefix = options.prefix;
    }
    if (options?.directories) {
      parameters.directories = "true";
    }
    return {
      [Symbol.asyncIterator]() {
        let currentCursor = null;
        let done = false;
        return {
          async next() {
            if (done) {
              return { done: true, value: void 0 };
            }
            const nextParameters = { ...parameters };
            if (currentCursor !== null) {
              nextParameters.cursor = currentCursor;
            }
            const res = await client.makeRequest({
              method: "get",
              parameters: nextParameters,
              storeName
            });
            let blobs = [];
            let directories = [];
            if (![200, 204, 404].includes(res.status)) {
              throw new BlobsInternalError(res);
            }
            if (res.status === 404) {
              done = true;
            } else {
              const page = await res.json();
              if (page.next_cursor) {
                currentCursor = page.next_cursor;
              } else {
                done = true;
              }
              blobs = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
              directories = page.directories ?? [];
            }
            return {
              done: false,
              value: {
                blobs,
                directories
              }
            };
          }
        };
      }
    };
  }
};
var getStore = (input) => {
  if (typeof input === "string") {
    const clientOptions = getClientOptions({});
    const client = new Client(clientOptions);
    return new Store({ client, name: input });
  }
  if (typeof input?.name === "string" && typeof input?.siteID === "string" && typeof input?.token === "string") {
    const { name, siteID, token } = input;
    const clientOptions = getClientOptions(input, { siteID, token });
    if (!name || !siteID || !token) {
      throw new MissingBlobsEnvironmentError(["name", "siteID", "token"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, name });
  }
  if (typeof input?.name === "string") {
    const { name } = input;
    const clientOptions = getClientOptions(input);
    if (!name) {
      throw new MissingBlobsEnvironmentError(["name"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, name });
  }
  if (typeof input?.deployID === "string") {
    const clientOptions = getClientOptions(input);
    const { deployID } = input;
    if (!deployID) {
      throw new MissingBlobsEnvironmentError(["deployID"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, deployID });
  }
  throw new Error(
    "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
  );
};

// netlify/functions/lib/runtime.mjs
var import_node_crypto = __toESM(require("crypto"), 1);
var OPENAI_MODEL = process.env.OPENAI_MODEL ?? "gpt-4o-mini";
var MAX_RUN_EVENTS = 500;
function getRunsStore() {
  return getStore("runs");
}
function getProjectsStore() {
  return getStore("projects");
}
function getMetaStore() {
  return getStore("meta");
}
async function getRunManuscriptSnapshot(runId) {
  const safeRunId = safeName(runId);
  if (!safeRunId) return null;
  const meta = await readJsonValue(getRunsStore(), `${safeRunId}.manuscript.meta.json`, null);
  const text = await getRunsStore().get(`${safeRunId}.manuscript.txt`, { type: "text" }).catch(() => null);
  if (!text) return null;
  return {
    text,
    updatedAt: String(meta?.updatedAt ?? ""),
    wordCount: meta?.wordCount ?? 0,
    lastAgentId: String(meta?.lastAgentId ?? ""),
    lastAgentName: String(meta?.lastAgentName ?? ""),
    lastStage: String(meta?.lastStage ?? ""),
    chapterIndex: meta?.chapterIndex ?? null,
    segmentIndex: meta?.segmentIndex ?? null,
    segmentStart: meta?.segmentStart ?? null,
    segmentEnd: meta?.segmentEnd ?? null,
    segmentCount: meta?.segmentCount ?? null,
    chapterCount: meta?.chapterCount ?? null
  };
}
async function loadRunDirectives(runId) {
  const safeRunId = safeName(runId);
  if (!safeRunId) return { items: [] };
  return readJsonValue(getRunsStore(), `${safeRunId}.directives.json`, { items: [] });
}
async function appendRunDirective(runId, item) {
  const safeRunId = safeName(runId);
  if (!safeRunId) return null;
  const existing = await loadRunDirectives(runId);
  const items = Array.isArray(existing?.items) ? existing.items : [];
  const next = {
    ...existing,
    items: [...items, item].slice(-200)
  };
  await writeJsonValue(getRunsStore(), `${safeRunId}.directives.json`, next);
  return item;
}
async function setActiveRunDirective(runId, active) {
  const safeRunId = safeName(runId);
  if (!safeRunId) return false;
  await writeJsonValue(getRunsStore(), `${safeRunId}.directive.active.json`, active ?? null);
  return true;
}
async function getActiveRunDirective(runId) {
  const safeRunId = safeName(runId);
  if (!safeRunId) return null;
  return readJsonValue(getRunsStore(), `${safeRunId}.directive.active.json`, null);
}
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function safeName(input) {
  const v = String(input ?? "").trim();
  if (!v) return null;
  const cleaned = v.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 120);
  if (!cleaned) return null;
  return cleaned;
}
async function readJsonValue(store, key, fallback) {
  const value = await store.get(key, { type: "json" }).catch(() => null);
  return value ?? fallback;
}
async function writeJsonValue(store, key, value) {
  await store.setJSON(key, value);
}
async function loadLibraryIndex() {
  return readJsonValue(getMetaStore(), "library-index", { folders: {}, items: {} });
}
async function saveLibraryIndex(data) {
  await writeJsonValue(getMetaStore(), "library-index", data ?? { folders: {}, items: {} });
}
async function loadProjectIndex() {
  return readJsonValue(getMetaStore(), "projects-index", { items: [] });
}
async function saveProjectIndex(data) {
  await writeJsonValue(getMetaStore(), "projects-index", data ?? { items: [] });
}
async function loadRunIndex() {
  return readJsonValue(getMetaStore(), "runs-index", { items: [] });
}
async function saveRunIndex(data) {
  await writeJsonValue(getMetaStore(), "runs-index", data ?? { items: [] });
}
function sanitizePayload(payload) {
  if (!payload || typeof payload !== "object") return payload ?? null;
  const clone = { ...payload };
  delete clone.openaiApiKey;
  delete clone.anthropicApiKey;
  delete clone.geminiApiKey;
  return clone;
}
async function saveProjectRecord(project) {
  const payload = {
    ...project,
    updatedAt: project?.updatedAt ?? nowIso()
  };
  const serialized = JSON.stringify(payload, null, 2);
  await getProjectsStore().set(`${payload.id}.json`, serialized, { contentType: "application/json; charset=utf-8" });
  const index = await loadProjectIndex();
  const items = Array.isArray(index?.items) ? index.items : [];
  const nextItem = {
    id: payload.id,
    file: `${payload.id}.json`,
    updatedAt: payload.updatedAt,
    size: Buffer.byteLength(serialized, "utf8"),
    title: payload.title ?? ""
  };
  const filtered = items.filter((item) => item?.id !== payload.id);
  filtered.unshift(nextItem);
  filtered.sort((a, b) => String(a?.updatedAt ?? "") < String(b?.updatedAt ?? "") ? 1 : -1);
  await saveProjectIndex({ items: filtered.slice(0, 1e3) });
  return payload;
}
async function getProjectRecord(id) {
  const safeId = safeName(id);
  if (!safeId) return null;
  const text = await getProjectsStore().get(`${safeId}.json`, { type: "text" }).catch(() => null);
  if (!text) return null;
  return JSON.parse(text);
}
async function listProjectRecords() {
  const index = await loadProjectIndex();
  const items = Array.isArray(index?.items) ? index.items : [];
  return items.sort((a, b) => String(a?.updatedAt ?? "") < String(b?.updatedAt ?? "") ? 1 : -1);
}
async function updateProjectRecord(id, fields) {
  const existing = await getProjectRecord(id);
  if (!existing) return null;
  const updated = {
    ...existing,
    manuscript: typeof fields?.manuscript === "string" ? fields.manuscript : existing?.manuscript,
    polish: typeof fields?.polish === "string" ? fields.polish : existing?.polish,
    updatedAt: nowIso()
  };
  return saveProjectRecord(updated);
}
function summarizeRun(run) {
  return {
    id: run.id,
    title: run.title ?? run.payload?.title ?? "",
    status: run.status,
    stage: run.stage,
    progress: run.progress ?? 0,
    createdAt: run.createdAt,
    updatedAt: run.updatedAt,
    projectId: run.projectId ?? null
  };
}
async function getRunRecord(runId) {
  const safeRunId = safeName(runId);
  if (!safeRunId) return null;
  return readJsonValue(getRunsStore(), `${safeRunId}.json`, null);
}
async function saveRunRecord(run) {
  const payload = {
    ...run,
    updatedAt: nowIso()
  };
  await writeJsonValue(getRunsStore(), `${payload.id}.json`, payload);
  const index = await loadRunIndex();
  const items = Array.isArray(index?.items) ? index.items : [];
  const filtered = items.filter((item) => item?.id !== payload.id);
  filtered.unshift(summarizeRun(payload));
  filtered.sort((a, b) => String(a?.updatedAt ?? "") < String(b?.updatedAt ?? "") ? 1 : -1);
  await saveRunIndex({ items: filtered.slice(0, 500) });
  return payload;
}
async function createRunRecord(runId, payload) {
  const sanitized = sanitizePayload(payload);
  return saveRunRecord({
    id: runId,
    createdAt: nowIso(),
    updatedAt: nowIso(),
    payload: sanitized,
    title: sanitized?.title ?? "",
    status: "running",
    stage: "queued",
    progress: 0,
    projectId: null,
    cancelled: false,
    events: []
  });
}
async function listRunRecords() {
  const index = await loadRunIndex();
  const items = Array.isArray(index?.items) ? index.items : [];
  return items.sort((a, b) => String(a?.updatedAt ?? "") < String(b?.updatedAt ?? "") ? 1 : -1);
}
async function appendRunEvent(runId, evt) {
  const run = await getRunRecord(runId);
  if (!run) return null;
  const event = {
    id: import_node_crypto.default.randomUUID(),
    at: evt?.at ?? nowIso(),
    ...evt
  };
  const events = Array.isArray(run.events) ? run.events.slice(-(MAX_RUN_EVENTS - 1)) : [];
  events.push(event);
  const next = {
    ...run,
    events,
    stage: typeof event?.stage === "string" ? event.stage : run.stage,
    progress: typeof event?.progress === "number" ? event.progress : run.progress
  };
  if (event?.type === "run_completed") {
    next.status = "done";
    next.progress = 100;
    next.projectId = event?.projectId ?? run.projectId ?? null;
  }
  if (event?.type === "run_cancelled") next.status = "cancelled";
  if (event?.type === "run_error") next.status = "error";
  return saveRunRecord(next);
}
async function markRunCancelled(runId) {
  const run = await getRunRecord(runId);
  if (!run) return false;
  if (run.status === "done" || run.status === "error" || run.status === "cancelled") return true;
  await saveRunRecord({ ...run, cancelled: true });
  await appendRunEvent(runId, { type: "run_cancelled", runId, at: nowIso(), message: "Run cancelled", stage: run.stage, progress: run.progress ?? 0 });
  return true;
}
async function openaiChat({ apiKey, messages, temperature = 0.7, maxTokens = 1600 }) {
  const key = String(apiKey ?? process.env.OPENAI_API_KEY ?? "").trim();
  if (!key) throw new Error("Missing OPENAI_API_KEY");
  const resp = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${key}`
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      messages,
      temperature,
      max_tokens: maxTokens
    })
  });
  const data = await resp.json().catch(() => null);
  if (!resp.ok) {
    const msg = data?.error?.message ?? `OpenAI error (${resp.status})`;
    throw new Error(msg);
  }
  const content = data?.choices?.[0]?.message?.content;
  return typeof content === "string" ? content : "";
}
async function finalizeDirective({ apiKey, title, ideaText, answersText }) {
  const response2 = await openaiChat({
    apiKey,
    temperature: 0.2,
    maxTokens: 450,
    messages: [
      {
        role: "system",
        content: "You convert a user idea + their answers into a clean, actionable directive for a fiction-writing agent. Output only the directive."
      },
      {
        role: "user",
        content: `Book: ${title}

Idea:
${String(ideaText ?? "").slice(0, 2e3)}

Answers:
${String(answersText ?? "").slice(0, 2e3)}

Write a directive that:
- is concise
- lists constraints as bullet points if needed
- states what to change and where (which chapter/scene if known)
- avoids ambiguity
`
      }
    ]
  });
  return String(response2 ?? "").trim();
}
async function generateDirectiveQuestions({ apiKey, title, userText }) {
  const response2 = await openaiChat({
    apiKey,
    temperature: 0.2,
    maxTokens: 500,
    messages: [
      {
        role: "system",
        content: "You help a user inject a story directive mid-generation. Ask short, pointed questions to clarify intent and constraints. Output only questions."
      },
      {
        role: "user",
        content: `Book: ${title}

User directive:
${String(userText ?? "").slice(0, 2e3)}

Ask up to 3 questions. Format as:
1. ...
2. ...
3. ...`
      }
    ]
  });
  return String(response2 ?? "").trim();
}
async function generateEditNotes({ apiKey, manuscript }) {
  const text = String(manuscript ?? "");
  if (!text.trim()) return "";
  const excerpt = text.slice(0, 18e3);
  return openaiChat({
    apiKey,
    temperature: 0.25,
    maxTokens: 1200,
    messages: [
      {
        role: "system",
        content: "You are a senior developmental editor + line editor. Give practical, specific notes. No fluff. Output in bullet points."
      },
      {
        role: "user",
        content: "Read this manuscript excerpt and provide:\n- 5 developmental notes (structure/pacing/character/logic)\n- 5 line notes (style/clarity/voice)\n- 5 consistency/QC checks\n\n" + excerpt
      }
    ]
  });
}

// netlify/functions/api.mjs
function response(statusCode, body, headers = {}) {
  return {
    statusCode,
    headers: {
      "cache-control": "no-store",
      ...headers
    },
    body: typeof body === "string" ? body : JSON.stringify(body)
  };
}
function json(statusCode, body) {
  return response(statusCode, body, { "content-type": "application/json; charset=utf-8" });
}
function badRequest(message) {
  return json(400, { error: "bad_request", message });
}
function notFound() {
  return json(404, { error: "not_found" });
}
function methodNotAllowed() {
  return json(405, { error: "method_not_allowed" });
}
function parseBody(event) {
  if (!event?.body) return null;
  try {
    return JSON.parse(event.body);
  } catch {
    throw new Error("Invalid JSON");
  }
}
function getPath(event) {
  const rawPath = String(event?.path ?? "/");
  if (rawPath.startsWith("/.netlify/functions/api")) {
    const suffix = rawPath.slice("/.netlify/functions/api".length) || "/";
    const normalizedSuffix = suffix.startsWith("/") ? suffix : `/${suffix}`;
    return normalizedSuffix.startsWith("/api/") || normalizedSuffix === "/api" ? normalizedSuffix : `/api${normalizedSuffix === "/" ? "" : normalizedSuffix}`;
  }
  return rawPath;
}
function getBaseUrl(event) {
  if (event?.rawUrl) {
    const url = new URL(event.rawUrl);
    return `${url.protocol}//${url.host}`;
  }
  const proto = event?.headers?.["x-forwarded-proto"] ?? "https";
  const host = event?.headers?.host ?? "";
  return `${proto}://${host}`;
}
function normalizeRetryStage(stage) {
  const s = String(stage ?? "").trim().toLowerCase();
  if (s === "draft" || s === "review" || s === "revise" || s === "qc" || s === "edit") return s;
  return "draft";
}
function getOpenAiKeyFromBody(body) {
  return String(body?.openaiApiKey ?? "").trim();
}
async function handler(event) {
  if (event?.blobs) {
    connectLambda(event);
  }
  const method = String(event?.httpMethod ?? "GET").toUpperCase();
  const pathname = getPath(event);
  if (pathname === "/api/health") {
    if (method !== "GET") return methodNotAllowed();
    return json(200, { ok: true });
  }
  if (pathname === "/api/config") {
    if (method === "GET") {
      const openai = Boolean(String(process.env.OPENAI_API_KEY ?? "").trim());
      const anthropic = Boolean(String(process.env.ANTHROPIC_API_KEY ?? "").trim());
      const gemini = Boolean(String(process.env.GEMINI_API_KEY ?? "").trim());
      return json(200, {
        ok: true,
        model: OPENAI_MODEL,
        keys: { openai, anthropic, gemini },
        sourceHint: {
          openai: openai ? "env" : "missing",
          anthropic: anthropic ? "env" : "missing",
          gemini: gemini ? "env" : "missing"
        },
        runtimeKeyInjectionSupported: false
      });
    }
    if (method === "POST") {
      let body;
      try {
        body = parseBody(event) ?? {};
      } catch (err) {
        return badRequest(String(err?.message ?? err));
      }
      const openai = Boolean(String(body?.openai ?? "").trim() || String(process.env.OPENAI_API_KEY ?? "").trim());
      const anthropic = Boolean(String(body?.anthropic ?? "").trim() || String(process.env.ANTHROPIC_API_KEY ?? "").trim());
      const gemini = Boolean(String(body?.gemini ?? "").trim() || String(process.env.GEMINI_API_KEY ?? "").trim());
      return json(200, {
        ok: true,
        model: OPENAI_MODEL,
        keys: { openai, anthropic, gemini },
        sourceHint: {
          openai: String(body?.openai ?? "").trim() ? "request" : process.env.OPENAI_API_KEY ? "env" : "missing",
          anthropic: String(body?.anthropic ?? "").trim() ? "request" : process.env.ANTHROPIC_API_KEY ? "env" : "missing",
          gemini: String(body?.gemini ?? "").trim() ? "request" : process.env.GEMINI_API_KEY ? "env" : "missing"
        },
        runtimeKeyInjectionSupported: false
      });
    }
    return methodNotAllowed();
  }
  if (pathname === "/api/library") {
    if (method === "GET") {
      const index = await loadLibraryIndex();
      return json(200, index);
    }
    if (method === "POST") {
      let body;
      try {
        body = parseBody(event) ?? {};
      } catch (err) {
        return badRequest(String(err?.message ?? err));
      }
      const index = await loadLibraryIndex();
      const { action, payload } = body;
      if (action === "createFolder") {
        const folderId = safeName(payload?.folderId) ?? import_node_crypto2.default.randomUUID();
        index.folders[folderId] = {
          id: folderId,
          name: String(payload?.name ?? ""),
          color: String(payload?.color ?? ""),
          children: Array.isArray(payload?.children) ? payload.children : []
        };
        await saveLibraryIndex(index);
        return json(200, { ok: true, folderId });
      }
      if (action === "updateItem") {
        const projectId = safeName(payload?.projectId);
        if (!projectId) return badRequest("Missing projectId");
        index.items[projectId] = payload?.metadata ?? null;
        await saveLibraryIndex(index);
        return json(200, { ok: true });
      }
      if (action === "deleteItem") {
        const projectId = safeName(payload?.projectId);
        if (!projectId) return badRequest("Missing projectId");
        delete index.items[projectId];
        await saveLibraryIndex(index);
        return json(200, { ok: true });
      }
      return badRequest("Unsupported action");
    }
    return methodNotAllowed();
  }
  if (pathname === "/api/runs") {
    if (method === "GET") {
      const items = await listRunRecords();
      return json(200, { items });
    }
    if (method === "POST") {
      let body;
      try {
        body = parseBody(event) ?? {};
      } catch (err) {
        return badRequest(String(err?.message ?? err));
      }
      const openaiApiKey = getOpenAiKeyFromBody(body) || String(process.env.OPENAI_API_KEY ?? "").trim();
      if (!openaiApiKey) {
        return json(400, { ok: false, error: "missing_openai_key", message: "Missing OPENAI_API_KEY" });
      }
      const runId = import_node_crypto2.default.randomUUID();
      const payload = sanitizePayload(body ?? null);
      await createRunRecord(runId, payload);
      await appendRunEvent(runId, { type: "run_started", runId, at: nowIso(), title: payload?.title ?? "", stage: "queued", progress: 0 });
      const backgroundUrl = `${getBaseUrl(event)}/.netlify/functions/run-generator-background`;
      await fetch(backgroundUrl, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ runId, payload, openaiApiKey })
      });
      return json(200, { ok: true, runId });
    }
    return methodNotAllowed();
  }
  if (pathname.startsWith("/api/runs/") && pathname.endsWith("/cancel")) {
    if (method !== "POST") return methodNotAllowed();
    const runId = safeName(pathname.replace("/api/runs/", "").replace("/cancel", ""));
    if (!runId) return badRequest("Missing runId");
    const cancelled = await markRunCancelled(runId);
    return json(200, { ok: true, cancelled });
  }
  if (pathname.startsWith("/api/runs/") && pathname.endsWith("/reinit")) {
    if (method !== "POST") return methodNotAllowed();
    const runId = safeName(pathname.replace("/api/runs/", "").replace("/reinit", ""));
    if (!runId) return badRequest("Missing runId");
    const run = await getRunRecord(runId);
    if (!run) return notFound();
    let body;
    try {
      body = parseBody(event) ?? {};
    } catch (err) {
      return badRequest(String(err?.message ?? err));
    }
    const cancelOld = body?.cancelOld !== false;
    const openaiApiKey = getOpenAiKeyFromBody(body) || String(process.env.OPENAI_API_KEY ?? "").trim();
    if (!openaiApiKey) {
      return json(400, { ok: false, error: "missing_openai_key", message: "Missing OPENAI_API_KEY" });
    }
    const payload = sanitizePayload(run?.payload ?? null);
    const newRunId = import_node_crypto2.default.randomUUID();
    await createRunRecord(newRunId, payload);
    await appendRunEvent(newRunId, { type: "run_started", runId: newRunId, at: nowIso(), title: payload?.title ?? "", stage: "queued", progress: 0 });
    if (cancelOld) {
      await markRunCancelled(runId);
      await appendRunEvent(runId, { type: "agent_event", runId, at: nowIso(), agentId: "system", agentName: "System", stage: "reinit", progress: run?.progress ?? 0, message: `Reinitialised (spawned new run ${newRunId})` });
    }
    const backgroundUrl = `${getBaseUrl(event)}/.netlify/functions/run-generator-background`;
    await fetch(backgroundUrl, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ runId: newRunId, payload, openaiApiKey })
    });
    return json(200, { ok: true, runId: newRunId, cancelledOld: cancelOld, oldRunId: runId });
  }
  if (pathname.startsWith("/api/runs/") && pathname.endsWith("/retry-segment")) {
    if (method !== "POST") return methodNotAllowed();
    const runId = safeName(pathname.replace("/api/runs/", "").replace("/retry-segment", ""));
    if (!runId) return badRequest("Missing runId");
    const run = await getRunRecord(runId);
    if (!run) return notFound();
    let body;
    try {
      body = parseBody(event) ?? {};
    } catch (err) {
      return badRequest(String(err?.message ?? err));
    }
    const openaiApiKey = getOpenAiKeyFromBody(body) || String(process.env.OPENAI_API_KEY ?? "").trim();
    if (!openaiApiKey) {
      return json(400, { ok: false, error: "missing_openai_key", message: "Missing OPENAI_API_KEY" });
    }
    const snapshot = await getRunManuscriptSnapshot(runId);
    if (!snapshot?.text) {
      return json(400, { ok: false, error: "missing_snapshot", message: "No manuscript snapshot exists yet for this run" });
    }
    const resume = {
      stage: normalizeRetryStage(body?.stageOverride || snapshot?.lastStage || "draft"),
      chapterIndex: snapshot?.chapterIndex ?? 0,
      segmentIndex: snapshot?.segmentIndex ?? 0,
      segmentStart: snapshot?.segmentStart ?? null,
      segmentEnd: snapshot?.segmentEnd ?? null,
      manuscriptText: snapshot.text,
      progress: typeof run?.progress === "number" ? run.progress : void 0
    };
    await appendRunEvent(runId, {
      type: "agent_event",
      runId,
      at: nowIso(),
      agentId: "system",
      agentName: "System",
      stage: "retry",
      progress: run?.progress ?? 0,
      message: `Retry requested: ${String(resume.stage).toUpperCase()} (Chapter ${Number(resume.chapterIndex) || 0}, Segment ${Number(resume.segmentIndex) + 1 || 0})`
    });
    const payload = sanitizePayload(run?.payload ?? null);
    const backgroundUrl = `${getBaseUrl(event)}/.netlify/functions/run-generator-background`;
    await fetch(backgroundUrl, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ runId, payload, openaiApiKey, resume })
    });
    return json(200, { ok: true, runId, resume });
  }
  if (pathname.startsWith("/api/runs/") && pathname.endsWith("/manuscript")) {
    if (method !== "GET") return methodNotAllowed();
    const runId = safeName(pathname.replace("/api/runs/", "").replace("/manuscript", ""));
    if (!runId) return badRequest("Missing runId");
    const snapshot = await getRunManuscriptSnapshot(runId);
    if (snapshot) return json(200, snapshot);
    const run = await getRunRecord(runId);
    if (!run) return notFound();
    return json(200, { text: "", updatedAt: "", wordCount: 0 });
  }
  if (pathname.startsWith("/api/runs/") && pathname.endsWith("/directives")) {
    const runId = safeName(pathname.replace("/api/runs/", "").replace("/directives", ""));
    if (!runId) return badRequest("Missing runId");
    if (method === "GET") {
      const run = await getRunRecord(runId);
      if (!run) return notFound();
      const items = await loadRunDirectives(runId);
      const active = await getActiveRunDirective(runId);
      return json(200, { ok: true, items: items?.items ?? [], active: active ?? null });
    }
    return methodNotAllowed();
  }
  if (pathname.startsWith("/api/runs/") && pathname.endsWith("/directives/questions")) {
    if (method !== "POST") return methodNotAllowed();
    const runId = safeName(pathname.replace("/api/runs/", "").replace("/directives/questions", ""));
    if (!runId) return badRequest("Missing runId");
    const run = await getRunRecord(runId);
    if (!run) return notFound();
    let body;
    try {
      body = parseBody(event) ?? {};
    } catch (err) {
      return badRequest(String(err?.message ?? err));
    }
    const apiKey = getOpenAiKeyFromBody(body) || String(process.env.OPENAI_API_KEY ?? "").trim();
    if (!apiKey) return json(400, { ok: false, error: "missing_openai_key", message: "Missing OPENAI_API_KEY" });
    const ideaText = String(body?.text ?? "").trim();
    if (!ideaText) return badRequest("Missing text");
    try {
      const questions = await generateDirectiveQuestions({ apiKey, title: String(run?.title ?? ""), userText: ideaText });
      return json(200, { ok: true, questions });
    } catch (err) {
      return json(500, { ok: false, error: "directive_questions_failed", message: String(err?.message ?? err) });
    }
  }
  if (pathname.startsWith("/api/runs/") && pathname.endsWith("/directives/apply")) {
    if (method !== "POST") return methodNotAllowed();
    const runId = safeName(pathname.replace("/api/runs/", "").replace("/directives/apply", ""));
    if (!runId) return badRequest("Missing runId");
    const run = await getRunRecord(runId);
    if (!run) return notFound();
    let body;
    try {
      body = parseBody(event) ?? {};
    } catch (err) {
      return badRequest(String(err?.message ?? err));
    }
    const apiKey = getOpenAiKeyFromBody(body) || String(process.env.OPENAI_API_KEY ?? "").trim();
    if (!apiKey) return json(400, { ok: false, error: "missing_openai_key", message: "Missing OPENAI_API_KEY" });
    const ideaText = String(body?.ideaText ?? "").trim();
    const answersText = String(body?.answersText ?? "").trim();
    if (!ideaText) return badRequest("Missing ideaText");
    if (!answersText) return badRequest("Missing answersText");
    try {
      const directive = await finalizeDirective({ apiKey, title: String(run?.title ?? ""), ideaText, answersText });
      const item = {
        id: import_node_crypto2.default.randomUUID(),
        at: nowIso(),
        ideaText,
        answersText,
        directive
      };
      await appendRunDirective(runId, item);
      await setActiveRunDirective(runId, { id: item.id, at: item.at, text: directive });
      await appendRunEvent(runId, {
        type: "agent_event",
        runId,
        at: nowIso(),
        agentId: "user",
        agentName: "User",
        stage: "directive",
        message: "Directive applied",
        chunk: directive
      });
      return json(200, { ok: true, directive, active: { id: item.id, at: item.at, text: directive } });
    } catch (err) {
      return json(500, { ok: false, error: "directive_apply_failed", message: String(err?.message ?? err) });
    }
  }
  if (pathname.startsWith("/api/runs/")) {
    if (method !== "GET") return methodNotAllowed();
    const runId = safeName(pathname.replace("/api/runs/", "").replace("/events", ""));
    if (!runId) return badRequest("Missing runId");
    const run = await getRunRecord(runId);
    if (!run) return notFound();
    return json(200, run);
  }
  if (pathname === "/api/projects") {
    if (method === "GET") {
      const items = await listProjectRecords();
      return json(200, { items });
    }
    if (method === "POST") {
      let body;
      try {
        body = parseBody(event) ?? {};
      } catch (err) {
        return badRequest(String(err?.message ?? err));
      }
      const requestedId = safeName(body?.id);
      const id = requestedId ?? import_node_crypto2.default.randomUUID();
      await saveProjectRecord({
        id,
        title: String(body?.title ?? ""),
        data: body?.data ?? null,
        updatedAt: nowIso(),
        createdAt: body?.createdAt ?? nowIso()
      });
      return json(200, { ok: true, id });
    }
    return methodNotAllowed();
  }
  if (pathname.startsWith("/api/projects/") && pathname.endsWith("/edit-notes")) {
    if (method !== "POST") return methodNotAllowed();
    const id = safeName(pathname.replace("/api/projects/", "").replace("/edit-notes", ""));
    if (!id) return badRequest("Missing project id");
    let body;
    try {
      body = parseBody(event) ?? {};
    } catch (err) {
      return badRequest(String(err?.message ?? err));
    }
    const apiKey = getOpenAiKeyFromBody(body) || String(process.env.OPENAI_API_KEY ?? "").trim();
    if (!apiKey) return json(400, { ok: false, error: "missing_openai_key", message: "Missing OPENAI_API_KEY" });
    try {
      const notes = await generateEditNotes({ apiKey, manuscript: body?.manuscript ?? "" });
      return json(200, { ok: true, notes });
    } catch (err) {
      return json(500, { ok: false, error: "edit_notes_failed", message: String(err?.message ?? err) });
    }
  }
  if (pathname.startsWith("/api/projects/") && pathname.endsWith("/manuscript")) {
    if (method !== "GET") return methodNotAllowed();
    const id = safeName(pathname.replace("/api/projects/", "").replace("/manuscript", ""));
    if (!id) return badRequest("Missing project id");
    const project = await getProjectRecord(id);
    if (!project) return notFound();
    return response(200, String(project?.manuscript ?? ""), { "content-type": "text/plain; charset=utf-8" });
  }
  if (pathname.startsWith("/api/projects/")) {
    const id = safeName(pathname.replace("/api/projects/", ""));
    if (!id) return badRequest("Missing project id");
    if (method === "GET") {
      const project = await getProjectRecord(id);
      if (!project) return notFound();
      return json(200, project);
    }
    if (method === "PUT") {
      let body;
      try {
        body = parseBody(event) ?? {};
      } catch (err) {
        return badRequest(String(err?.message ?? err));
      }
      const updated = await updateProjectRecord(id, body);
      if (!updated) return notFound();
      return json(200, { ok: true, id });
    }
    return methodNotAllowed();
  }
  return notFound();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});

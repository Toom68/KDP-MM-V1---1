"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/run-generator-background.mjs
var run_generator_background_exports = {};
__export(run_generator_background_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(run_generator_background_exports);

// node_modules/@netlify/blobs/dist/chunk-XR3MUBBK.js
var NF_ERROR = "x-nf-error";
var NF_REQUEST_ID = "x-nf-request-id";
var BlobsInternalError = class extends Error {
  constructor(res) {
    let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
    if (res.headers.has(NF_REQUEST_ID)) {
      details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
    }
    super(`Netlify Blobs has generated an internal error (${details})`);
    this.name = "BlobsInternalError";
  }
};
var collectIterator = async (iterator) => {
  const result = [];
  for await (const item of iterator) {
    result.push(item);
  }
  return result;
};
var base64Decode = (input) => {
  const { Buffer: Buffer2 } = globalThis;
  if (Buffer2) {
    return Buffer2.from(input, "base64").toString();
  }
  return atob(input);
};
var base64Encode = (input) => {
  const { Buffer: Buffer2 } = globalThis;
  if (Buffer2) {
    return Buffer2.from(input).toString("base64");
  }
  return btoa(input);
};
var getEnvironment = () => {
  const { Deno, Netlify, process: process2 } = globalThis;
  return Netlify?.env ?? Deno?.env ?? {
    delete: (key) => delete process2?.env[key],
    get: (key) => process2?.env[key],
    has: (key) => Boolean(process2?.env[key]),
    set: (key, value) => {
      if (process2?.env) {
        process2.env[key] = value;
      }
    },
    toObject: () => process2?.env ?? {}
  };
};
var getEnvironmentContext = () => {
  const context = globalThis.netlifyBlobsContext || getEnvironment().get("NETLIFY_BLOBS_CONTEXT");
  if (typeof context !== "string" || !context) {
    return {};
  }
  const data = base64Decode(context);
  try {
    return JSON.parse(data);
  } catch {
  }
  return {};
};
var setEnvironmentContext = (context) => {
  const encodedContext = base64Encode(JSON.stringify(context));
  getEnvironment().set("NETLIFY_BLOBS_CONTEXT", encodedContext);
};
var MissingBlobsEnvironmentError = class extends Error {
  constructor(requiredProperties) {
    super(
      `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
        ", "
      )}`
    );
    this.name = "MissingBlobsEnvironmentError";
  }
};
var BASE64_PREFIX = "b64;";
var METADATA_HEADER_INTERNAL = "x-amz-meta-user";
var METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
var METADATA_MAX_SIZE = 2 * 1024;
var encodeMetadata = (metadata) => {
  if (!metadata) {
    return null;
  }
  const encodedObject = base64Encode(JSON.stringify(metadata));
  const payload = `b64;${encodedObject}`;
  if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
    throw new Error("Metadata object exceeds the maximum size");
  }
  return payload;
};
var decodeMetadata = (header) => {
  if (!header || !header.startsWith(BASE64_PREFIX)) {
    return {};
  }
  const encodedData = header.slice(BASE64_PREFIX.length);
  const decodedData = base64Decode(encodedData);
  const metadata = JSON.parse(decodedData);
  return metadata;
};
var getMetadataFromResponse = (response) => {
  if (!response.headers) {
    return {};
  }
  const value = response.headers.get(METADATA_HEADER_EXTERNAL) || response.headers.get(METADATA_HEADER_INTERNAL);
  try {
    return decodeMetadata(value);
  } catch {
    throw new Error(
      "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
    );
  }
};
var BlobsConsistencyError = class extends Error {
  constructor() {
    super(
      `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
    );
    this.name = "BlobsConsistencyError";
  }
};
var regions = {
  "us-east-1": true,
  "us-east-2": true,
  "eu-central-1": true,
  "ap-southeast-1": true,
  "ap-southeast-2": true
};
var isValidRegion = (input) => Object.keys(regions).includes(input);
var InvalidBlobsRegionError = class extends Error {
  constructor(region) {
    super(
      `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
    );
    this.name = "InvalidBlobsRegionError";
  }
};
var DEFAULT_RETRY_DELAY = getEnvironment().get("NODE_ENV") === "test" ? 1 : 5e3;
var MIN_RETRY_DELAY = 1e3;
var MAX_RETRY = 5;
var RATE_LIMIT_HEADER = "X-RateLimit-Reset";
var fetchAndRetry = async (fetch2, url, options, attemptsLeft = MAX_RETRY) => {
  try {
    const res = await fetch2(url, options);
    if (attemptsLeft > 0 && (res.status === 429 || res.status >= 500)) {
      const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
      await sleep(delay);
      return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
    }
    return res;
  } catch (error) {
    if (attemptsLeft === 0) {
      throw error;
    }
    const delay = getDelay();
    await sleep(delay);
    return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
  }
};
var getDelay = (rateLimitReset) => {
  if (!rateLimitReset) {
    return DEFAULT_RETRY_DELAY;
  }
  return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
};
var sleep = (ms) => new Promise((resolve) => {
  setTimeout(resolve, ms);
});
var SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
var Client = class {
  constructor({ apiURL, consistency, edgeURL, fetch: fetch2, region, siteID, token, uncachedEdgeURL }) {
    this.apiURL = apiURL;
    this.consistency = consistency ?? "eventual";
    this.edgeURL = edgeURL;
    this.fetch = fetch2 ?? globalThis.fetch;
    this.region = region;
    this.siteID = siteID;
    this.token = token;
    this.uncachedEdgeURL = uncachedEdgeURL;
    if (!this.fetch) {
      throw new Error(
        "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
      );
    }
  }
  async getFinalRequest({
    consistency: opConsistency,
    key,
    metadata,
    method,
    parameters = {},
    storeName
  }) {
    const encodedMetadata = encodeMetadata(metadata);
    const consistency = opConsistency ?? this.consistency;
    let urlPath = `/${this.siteID}`;
    if (storeName) {
      urlPath += `/${storeName}`;
    }
    if (key) {
      urlPath += `/${key}`;
    }
    if (this.edgeURL) {
      if (consistency === "strong" && !this.uncachedEdgeURL) {
        throw new BlobsConsistencyError();
      }
      const headers = {
        authorization: `Bearer ${this.token}`
      };
      if (encodedMetadata) {
        headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
      }
      if (this.region) {
        urlPath = `/region:${this.region}${urlPath}`;
      }
      const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
      for (const key2 in parameters) {
        url2.searchParams.set(key2, parameters[key2]);
      }
      return {
        headers,
        url: url2.toString()
      };
    }
    const apiHeaders = { authorization: `Bearer ${this.token}` };
    const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
    for (const key2 in parameters) {
      url.searchParams.set(key2, parameters[key2]);
    }
    if (this.region) {
      url.searchParams.set("region", this.region);
    }
    if (storeName === void 0 || key === void 0) {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    if (encodedMetadata) {
      apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
    }
    if (method === "head" || method === "delete") {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    const res = await this.fetch(url.toString(), {
      headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
      method
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
    const { url: signedURL } = await res.json();
    const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
    return {
      headers: userHeaders,
      url: signedURL
    };
  }
  async makeRequest({
    body,
    consistency,
    headers: extraHeaders,
    key,
    metadata,
    method,
    parameters,
    storeName
  }) {
    const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
      consistency,
      key,
      metadata,
      method,
      parameters,
      storeName
    });
    const headers = {
      ...baseHeaders,
      ...extraHeaders
    };
    if (method === "put") {
      headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
    }
    const options = {
      body,
      headers,
      method
    };
    if (body instanceof ReadableStream) {
      options.duplex = "half";
    }
    return fetchAndRetry(this.fetch, url, options);
  }
};
var getClientOptions = (options, contextOverride) => {
  const context = contextOverride ?? getEnvironmentContext();
  const siteID = context.siteID ?? options.siteID;
  const token = context.token ?? options.token;
  if (!siteID || !token) {
    throw new MissingBlobsEnvironmentError(["siteID", "token"]);
  }
  if (options.region !== void 0 && !isValidRegion(options.region)) {
    throw new InvalidBlobsRegionError(options.region);
  }
  const clientOptions = {
    apiURL: context.apiURL ?? options.apiURL,
    consistency: options.consistency,
    edgeURL: context.edgeURL ?? options.edgeURL,
    fetch: options.fetch,
    region: options.region,
    siteID,
    token,
    uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
  };
  return clientOptions;
};

// node_modules/@netlify/blobs/dist/main.js
var connectLambda = (event) => {
  const rawData = base64Decode(event.blobs);
  const data = JSON.parse(rawData);
  const environmentContext = {
    deployID: event.headers["x-nf-deploy-id"],
    edgeURL: data.url,
    siteID: event.headers["x-nf-site-id"],
    token: data.token
  };
  setEnvironmentContext(environmentContext);
};
var DEPLOY_STORE_PREFIX = "deploy:";
var LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
var SITE_STORE_PREFIX = "site:";
var Store = class _Store {
  constructor(options) {
    this.client = options.client;
    if ("deployID" in options) {
      _Store.validateDeployID(options.deployID);
      let name = DEPLOY_STORE_PREFIX + options.deployID;
      if (options.name) {
        name += `:${options.name}`;
      }
      this.name = name;
    } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
      const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
      _Store.validateStoreName(storeName);
      this.name = storeName;
    } else {
      _Store.validateStoreName(options.name);
      this.name = SITE_STORE_PREFIX + options.name;
    }
  }
  async delete(key) {
    const res = await this.client.makeRequest({ key, method: "delete", storeName: this.name });
    if (![200, 204, 404].includes(res.status)) {
      throw new BlobsInternalError(res);
    }
  }
  async get(key, options) {
    const { consistency, type } = options ?? {};
    const res = await this.client.makeRequest({ consistency, key, method: "get", storeName: this.name });
    if (res.status === 404) {
      return null;
    }
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
    if (type === void 0 || type === "text") {
      return res.text();
    }
    if (type === "arrayBuffer") {
      return res.arrayBuffer();
    }
    if (type === "blob") {
      return res.blob();
    }
    if (type === "json") {
      return res.json();
    }
    if (type === "stream") {
      return res.body;
    }
    throw new BlobsInternalError(res);
  }
  async getMetadata(key, { consistency } = {}) {
    const res = await this.client.makeRequest({ consistency, key, method: "head", storeName: this.name });
    if (res.status === 404) {
      return null;
    }
    if (res.status !== 200 && res.status !== 304) {
      throw new BlobsInternalError(res);
    }
    const etag = res?.headers.get("etag") ?? void 0;
    const metadata = getMetadataFromResponse(res);
    const result = {
      etag,
      metadata
    };
    return result;
  }
  async getWithMetadata(key, options) {
    const { consistency, etag: requestETag, type } = options ?? {};
    const headers = requestETag ? { "if-none-match": requestETag } : void 0;
    const res = await this.client.makeRequest({
      consistency,
      headers,
      key,
      method: "get",
      storeName: this.name
    });
    if (res.status === 404) {
      return null;
    }
    if (res.status !== 200 && res.status !== 304) {
      throw new BlobsInternalError(res);
    }
    const responseETag = res?.headers.get("etag") ?? void 0;
    const metadata = getMetadataFromResponse(res);
    const result = {
      etag: responseETag,
      metadata
    };
    if (res.status === 304 && requestETag) {
      return { data: null, ...result };
    }
    if (type === void 0 || type === "text") {
      return { data: await res.text(), ...result };
    }
    if (type === "arrayBuffer") {
      return { data: await res.arrayBuffer(), ...result };
    }
    if (type === "blob") {
      return { data: await res.blob(), ...result };
    }
    if (type === "json") {
      return { data: await res.json(), ...result };
    }
    if (type === "stream") {
      return { data: res.body, ...result };
    }
    throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
  }
  list(options = {}) {
    const iterator = this.getListIterator(options);
    if (options.paginate) {
      return iterator;
    }
    return collectIterator(iterator).then(
      (items) => items.reduce(
        (acc, item) => ({
          blobs: [...acc.blobs, ...item.blobs],
          directories: [...acc.directories, ...item.directories]
        }),
        { blobs: [], directories: [] }
      )
    );
  }
  async set(key, data, { metadata } = {}) {
    _Store.validateKey(key);
    const res = await this.client.makeRequest({
      body: data,
      key,
      metadata,
      method: "put",
      storeName: this.name
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
  }
  async setJSON(key, data, { metadata } = {}) {
    _Store.validateKey(key);
    const payload = JSON.stringify(data);
    const headers = {
      "content-type": "application/json"
    };
    const res = await this.client.makeRequest({
      body: payload,
      headers,
      key,
      metadata,
      method: "put",
      storeName: this.name
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
  }
  static formatListResultBlob(result) {
    if (!result.key) {
      return null;
    }
    return {
      etag: result.etag,
      key: result.key
    };
  }
  static validateKey(key) {
    if (key === "") {
      throw new Error("Blob key must not be empty.");
    }
    if (key.startsWith("/") || key.startsWith("%2F")) {
      throw new Error("Blob key must not start with forward slash (/).");
    }
    if (new TextEncoder().encode(key).length > 600) {
      throw new Error(
        "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
      );
    }
  }
  static validateDeployID(deployID) {
    if (!/^\w{1,24}$/.test(deployID)) {
      throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
    }
  }
  static validateStoreName(name) {
    if (name.includes("/") || name.includes("%2F")) {
      throw new Error("Store name must not contain forward slashes (/).");
    }
    if (new TextEncoder().encode(name).length > 64) {
      throw new Error(
        "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
      );
    }
  }
  getListIterator(options) {
    const { client, name: storeName } = this;
    const parameters = {};
    if (options?.prefix) {
      parameters.prefix = options.prefix;
    }
    if (options?.directories) {
      parameters.directories = "true";
    }
    return {
      [Symbol.asyncIterator]() {
        let currentCursor = null;
        let done = false;
        return {
          async next() {
            if (done) {
              return { done: true, value: void 0 };
            }
            const nextParameters = { ...parameters };
            if (currentCursor !== null) {
              nextParameters.cursor = currentCursor;
            }
            const res = await client.makeRequest({
              method: "get",
              parameters: nextParameters,
              storeName
            });
            let blobs = [];
            let directories = [];
            if (![200, 204, 404].includes(res.status)) {
              throw new BlobsInternalError(res);
            }
            if (res.status === 404) {
              done = true;
            } else {
              const page = await res.json();
              if (page.next_cursor) {
                currentCursor = page.next_cursor;
              } else {
                done = true;
              }
              blobs = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
              directories = page.directories ?? [];
            }
            return {
              done: false,
              value: {
                blobs,
                directories
              }
            };
          }
        };
      }
    };
  }
};
var getStore = (input) => {
  if (typeof input === "string") {
    const clientOptions = getClientOptions({});
    const client = new Client(clientOptions);
    return new Store({ client, name: input });
  }
  if (typeof input?.name === "string" && typeof input?.siteID === "string" && typeof input?.token === "string") {
    const { name, siteID, token } = input;
    const clientOptions = getClientOptions(input, { siteID, token });
    if (!name || !siteID || !token) {
      throw new MissingBlobsEnvironmentError(["name", "siteID", "token"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, name });
  }
  if (typeof input?.name === "string") {
    const { name } = input;
    const clientOptions = getClientOptions(input);
    if (!name) {
      throw new MissingBlobsEnvironmentError(["name"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, name });
  }
  if (typeof input?.deployID === "string") {
    const clientOptions = getClientOptions(input);
    const { deployID } = input;
    if (!deployID) {
      throw new MissingBlobsEnvironmentError(["deployID"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, deployID });
  }
  throw new Error(
    "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
  );
};

// netlify/functions/lib/runtime.mjs
var import_node_crypto = __toESM(require("crypto"), 1);
var OPENAI_MODEL = process.env.OPENAI_MODEL ?? "gpt-4o-mini";
var MAX_RUN_EVENTS = 500;
function getRunsStore() {
  return getStore("runs");
}
function getProjectsStore() {
  return getStore("projects");
}
function getMetaStore() {
  return getStore("meta");
}
async function saveRunManuscriptSnapshot(runId, text, meta = null) {
  const safeRunId = safeName(runId);
  if (!safeRunId) return false;
  const manuscript = String(text ?? "");
  const wordCount = countWords(manuscript);
  await getRunsStore().set(`${safeRunId}.manuscript.txt`, manuscript, { contentType: "text/plain; charset=utf-8" });
  await writeJsonValue(getRunsStore(), `${safeRunId}.manuscript.meta.json`, {
    updatedAt: nowIso(),
    wordCount,
    lastAgentId: typeof meta?.agentId === "string" ? meta.agentId : "",
    lastAgentName: typeof meta?.agentName === "string" ? meta.agentName : "",
    lastStage: typeof meta?.stage === "string" ? meta.stage : "",
    chapterIndex: Number.isFinite(Number(meta?.chapterIndex)) ? Number(meta.chapterIndex) : null,
    segmentIndex: Number.isFinite(Number(meta?.segmentIndex)) ? Number(meta.segmentIndex) : null,
    segmentStart: Number.isFinite(Number(meta?.segmentStart)) ? Number(meta.segmentStart) : null,
    segmentEnd: Number.isFinite(Number(meta?.segmentEnd)) ? Number(meta.segmentEnd) : null,
    segmentCount: Number.isFinite(Number(meta?.segmentCount)) ? Number(meta.segmentCount) : null,
    chapterCount: Number.isFinite(Number(meta?.chapterCount)) ? Number(meta.chapterCount) : null
  });
  return true;
}
async function getActiveRunDirective(runId) {
  const safeRunId = safeName(runId);
  if (!safeRunId) return null;
  return readJsonValue(getRunsStore(), `${safeRunId}.directive.active.json`, null);
}
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function safeName(input) {
  const v = String(input ?? "").trim();
  if (!v) return null;
  const cleaned = v.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 120);
  if (!cleaned) return null;
  return cleaned;
}
function countWords(text) {
  return String(text ?? "").trim().split(/\s+/).filter(Boolean).length;
}
function parseWordCountHint(value) {
  const raw = String(value ?? "").trim().toLowerCase();
  if (!raw) return null;
  const kMatch = raw.match(/(\d+(?:\.\d+)?)\s*k\b/);
  if (kMatch) return Math.round(Number(kMatch[1]) * 1e3);
  const numberMatch = raw.match(/\b(\d{2,3}(?:,\d{3})+)\b|\b(\d{5,6})\b/);
  const candidate = numberMatch?.[1] ?? numberMatch?.[2] ?? "";
  if (!candidate) return null;
  const parsed = Number(candidate.replace(/,/g, ""));
  return Number.isFinite(parsed) ? parsed : null;
}
function resolveGenerationPlan(payload) {
  const presets = {
    novella: { targetWords: 6e4, chapterCount: 12, reviewPasses: 1 },
    standard: { targetWords: 85e3, chapterCount: 18, reviewPasses: 2 },
    epic: { targetWords: 12e4, chapterCount: 24, reviewPasses: 3 }
  };
  const rawLength = String(payload?.length ?? "").trim();
  const preset = presets[rawLength.toLowerCase()] ?? presets.standard;
  const hintedWords = parseWordCountHint(rawLength);
  const requestedWords = Number(payload?.targetWords ?? hintedWords ?? preset.targetWords);
  const requestedChapters = Number(payload?.chapterCount ?? preset.chapterCount);
  const requestedPasses = Number(payload?.reviewPasses ?? preset.reviewPasses);
  const targetWords = Math.max(4e4, Math.min(14e4, Math.round(Number.isFinite(requestedWords) ? requestedWords : preset.targetWords)));
  const chapterCount = Math.max(8, Math.min(40, Math.round(Number.isFinite(requestedChapters) ? requestedChapters : preset.chapterCount)));
  const reviewPasses = Math.max(1, Math.min(3, Math.round(Number.isFinite(requestedPasses) ? requestedPasses : preset.reviewPasses)));
  const wordsPerChapter = Math.max(2500, Math.round(targetWords / chapterCount));
  const segmentCount = Math.max(2, Math.min(5, Math.ceil(wordsPerChapter / 1400)));
  const wordsPerSegment = Math.max(900, Math.round(wordsPerChapter / segmentCount));
  return {
    lengthLabel: rawLength,
    targetWords,
    chapterCount,
    reviewPasses,
    wordsPerChapter,
    segmentCount,
    wordsPerSegment
  };
}
function escapeRegex(text) {
  return String(text ?? "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function normalizeChapterSegment(text, heading, includeHeading) {
  let cleaned = String(text ?? "").trim();
  if (!cleaned) return includeHeading ? `## ${heading}` : "";
  const headingPattern = new RegExp(`^#{1,6}\\s*${escapeRegex(heading)}\\s*`, "i");
  cleaned = cleaned.replace(headingPattern, "").trim();
  if (includeHeading) {
    return `## ${heading}

${cleaned}`.trim();
  }
  return cleaned;
}
function extractChaptersFromOutline(outlineText) {
  const lines = String(outlineText ?? "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const chapters = [];
  for (const line of lines) {
    const m = line.match(/^(?:chapter\s*)?(\d{1,2})[\.:\-)]\s*(.+)$/i);
    if (m) {
      const raw = m[2].trim();
      const [titlePart, ...beatParts] = raw.split(/\s+[—-]\s+/);
      chapters.push({
        index: Number(m[1]),
        title: titlePart.trim() || `Chapter ${m[1]}`,
        beat: beatParts.join(" \u2014 ").trim()
      });
    }
  }
  if (chapters.length) return chapters.sort((a, b) => a.index - b.index);
  const fallback = [];
  for (let i = 1; i <= 18; i += 1) fallback.push({ index: i, title: `Chapter ${i}`, beat: "" });
  return fallback;
}
async function readJsonValue(store, key, fallback) {
  const value = await store.get(key, { type: "json" }).catch(() => null);
  return value ?? fallback;
}
async function writeJsonValue(store, key, value) {
  await store.setJSON(key, value);
}
async function loadProjectIndex() {
  return readJsonValue(getMetaStore(), "projects-index", { items: [] });
}
async function saveProjectIndex(data) {
  await writeJsonValue(getMetaStore(), "projects-index", data ?? { items: [] });
}
async function loadRunIndex() {
  return readJsonValue(getMetaStore(), "runs-index", { items: [] });
}
async function saveRunIndex(data) {
  await writeJsonValue(getMetaStore(), "runs-index", data ?? { items: [] });
}
async function saveProjectRecord(project) {
  const payload = {
    ...project,
    updatedAt: project?.updatedAt ?? nowIso()
  };
  const serialized = JSON.stringify(payload, null, 2);
  await getProjectsStore().set(`${payload.id}.json`, serialized, { contentType: "application/json; charset=utf-8" });
  const index = await loadProjectIndex();
  const items = Array.isArray(index?.items) ? index.items : [];
  const nextItem = {
    id: payload.id,
    file: `${payload.id}.json`,
    updatedAt: payload.updatedAt,
    size: Buffer.byteLength(serialized, "utf8"),
    title: payload.title ?? ""
  };
  const filtered = items.filter((item) => item?.id !== payload.id);
  filtered.unshift(nextItem);
  filtered.sort((a, b) => String(a?.updatedAt ?? "") < String(b?.updatedAt ?? "") ? 1 : -1);
  await saveProjectIndex({ items: filtered.slice(0, 1e3) });
  return payload;
}
function summarizeRun(run) {
  return {
    id: run.id,
    title: run.title ?? run.payload?.title ?? "",
    status: run.status,
    stage: run.stage,
    progress: run.progress ?? 0,
    createdAt: run.createdAt,
    updatedAt: run.updatedAt,
    projectId: run.projectId ?? null
  };
}
async function getRunRecord(runId) {
  const safeRunId = safeName(runId);
  if (!safeRunId) return null;
  return readJsonValue(getRunsStore(), `${safeRunId}.json`, null);
}
async function saveRunRecord(run) {
  const payload = {
    ...run,
    updatedAt: nowIso()
  };
  await writeJsonValue(getRunsStore(), `${payload.id}.json`, payload);
  const index = await loadRunIndex();
  const items = Array.isArray(index?.items) ? index.items : [];
  const filtered = items.filter((item) => item?.id !== payload.id);
  filtered.unshift(summarizeRun(payload));
  filtered.sort((a, b) => String(a?.updatedAt ?? "") < String(b?.updatedAt ?? "") ? 1 : -1);
  await saveRunIndex({ items: filtered.slice(0, 500) });
  return payload;
}
async function appendRunEvent(runId, evt) {
  const run = await getRunRecord(runId);
  if (!run) return null;
  const event = {
    id: import_node_crypto.default.randomUUID(),
    at: evt?.at ?? nowIso(),
    ...evt
  };
  const events = Array.isArray(run.events) ? run.events.slice(-(MAX_RUN_EVENTS - 1)) : [];
  events.push(event);
  const next = {
    ...run,
    events,
    stage: typeof event?.stage === "string" ? event.stage : run.stage,
    progress: typeof event?.progress === "number" ? event.progress : run.progress
  };
  if (event?.type === "run_completed") {
    next.status = "done";
    next.progress = 100;
    next.projectId = event?.projectId ?? run.projectId ?? null;
  }
  if (event?.type === "run_cancelled") next.status = "cancelled";
  if (event?.type === "run_error") next.status = "error";
  return saveRunRecord(next);
}
async function openaiChat({ apiKey, messages, temperature = 0.7, maxTokens = 1600 }) {
  const key = String(apiKey ?? process.env.OPENAI_API_KEY ?? "").trim();
  if (!key) throw new Error("Missing OPENAI_API_KEY");
  const resp = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${key}`
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      messages,
      temperature,
      max_tokens: maxTokens
    })
  });
  const data = await resp.json().catch(() => null);
  if (!resp.ok) {
    const msg = data?.error?.message ?? `OpenAI error (${resp.status})`;
    throw new Error(msg);
  }
  const content = data?.choices?.[0]?.message?.content;
  return typeof content === "string" ? content : "";
}
async function buildStoryBible({ apiKey, title, bookType, genre, subgenre, tone, blueprint, outline }) {
  const response = await openaiChat({
    apiKey,
    temperature: 0.15,
    maxTokens: 900,
    messages: [
      {
        role: "system",
        content: "You are a meticulous story continuity editor. Build a compact story bible that can be reused in prompts. Be concrete, avoid speculation, avoid prose. Output only the bible."
      },
      {
        role: "user",
        content: `Create a STORY BIBLE for this book.
Title: ${title}
Type: ${bookType}
Genre: ${genre}${subgenre ? ` / ${subgenre}` : ""}
Tone: ${tone || "default"}

` + (blueprint ? `Blueprint:
${blueprint}

` : "") + `Outline:
${outline}

Format EXACTLY as:
CHARACTERS:
- Name: role, age?, voice, desires, fears, secrets, relationships
SETTINGS:
- Place: sensory anchors, rules
TIMELINE / FACTS:
- bullet facts that must remain consistent
STYLE RULES:
- bullet rules for voice and prose
OPEN THREADS:
- bullet mysteries/promises to pay off

Keep it under 2200 characters.`
      }
    ]
  });
  return String(response ?? "").trim();
}
async function updateStoryMemory({ apiKey, title, storyBible, recap, newText, chapterLabel }) {
  const response = await openaiChat({
    apiKey,
    temperature: 0.2,
    maxTokens: 900,
    messages: [
      {
        role: "system",
        content: "You update story memory for continuity. Maintain stable facts. Do NOT invent new facts not supported by text. Keep output compact."
      },
      {
        role: "user",
        content: `Book: ${title}
Chapter: ${chapterLabel}

CURRENT STORY BIBLE:
${storyBible || "(none)"}

CURRENT ROLLING RECAP:
${recap || "(none)"}

NEW CANON TEXT (authoritative):
${String(newText ?? "").slice(0, 12e3)}

Return EXACTLY two sections:
STORY_BIBLE:
(updated bible, under 2400 chars)
RECAP:
(rolling recap of key events so far, under 900 chars)`
      }
    ]
  });
  const raw = String(response ?? "");
  const match = raw.match(/STORY_BIBLE:\s*([\s\S]*?)\nRECAP:\s*([\s\S]*)$/i);
  if (!match) {
    return {
      storyBible: String(storyBible ?? ""),
      recap: String(recap ?? "")
    };
  }
  return {
    storyBible: String(match[1] ?? "").trim(),
    recap: String(match[2] ?? "").trim()
  };
}
function buildContinuityBlock({ storyBible, recap, chapterBeat, chapterLabel }) {
  const bible = String(storyBible ?? "").trim();
  const rolling = String(recap ?? "").trim();
  const beat = String(chapterBeat ?? "").trim();
  return ("CONTINUITY MEMORY (authoritative):\n" + (bible ? `${bible}

` : "") + (rolling ? `ROLLING RECAP:
${rolling}

` : "") + (beat ? `CURRENT CHAPTER GOAL (${chapterLabel}):
${beat}

` : "") + "Rules:\n- Do not contradict the story bible or recap.\n- Preserve names, relationships, motives, injuries, locations, and timeline facts.\n- If uncertain, choose the safest interpretation consistent with prior canon.").trim();
}
async function generateBookRun({ runId, payload, apiKey, push, isCancelled, resume = null }) {
  const title = String(payload?.title ?? "").trim();
  const bookType = String(payload?.bookType ?? "fiction");
  const genre = String(payload?.genre ?? "").trim();
  const subgenre = String(payload?.subgenre ?? "").trim();
  const tone = String(payload?.tone ?? "").trim();
  const blueprint = String(payload?.blueprint ?? "").trim();
  const plan = resolveGenerationPlan(payload);
  const { lengthLabel, targetWords, chapterCount, reviewPasses, wordsPerChapter, segmentCount, wordsPerSegment } = plan;
  const resumeEnabled = Boolean(resume && typeof resume === "object");
  let manuscript = resumeEnabled && typeof resume?.manuscriptText === "string" ? String(resume.manuscriptText) : "";
  let outline = "";
  if (!resumeEnabled) {
    await push({
      type: "agent_event",
      runId,
      at: nowIso(),
      agentId: "planner",
      agentName: "Planner",
      stage: "outline",
      message: `Generating outline (${chapterCount} chapters ~${targetWords.toLocaleString()} words)`,
      progress: 5
    });
    const outlinePrompt = [
      { role: "system", content: "You are a senior book outliner. Output concise, high-quality structure with progression and escalating value." },
      {
        role: "user",
        content: `Create a chapter outline for a ${bookType} book.
Title: ${title}
Genre: ${genre}${subgenre ? ` / ${subgenre}` : ""}
Tone: ${tone || "default"}
Length label: ${lengthLabel || "custom"}
Target words: ${targetWords}
Target words per chapter: about ${wordsPerChapter}
` + (blueprint ? `Blueprint:
${blueprint}
` : "") + `
Return an outline with exactly ${chapterCount} lines formatted like: "1. Chapter title \u2014 1-2 sentence beat". Make every beat specific and cumulative.`
      }
    ];
    outline = await openaiChat({ apiKey, messages: outlinePrompt, temperature: 0.6, maxTokens: 1400 });
    if (await isCancelled()) return null;
    await push({
      type: "agent_event",
      runId,
      at: nowIso(),
      agentId: "planner",
      agentName: "Planner",
      stage: "outline",
      message: "Outline ready",
      progress: 12,
      chunk: outline
    });
  } else {
    outline = extractOutlineFromManuscript(manuscript);
    if (!outline) {
      throw new Error("Cannot resume run: missing outline in manuscript snapshot");
    }
    await push({
      type: "agent_event",
      runId,
      at: nowIso(),
      agentId: "system",
      agentName: "System",
      stage: "retry",
      message: `Retrying ${String(resume?.stage ?? "").toUpperCase() || "stage"} at Chapter ${Number(resume?.chapterIndex ?? 0) || 0}, Segment ${Number(resume?.segmentIndex ?? 0) + 1 || 0}`,
      progress: typeof resume?.progress === "number" ? resume.progress : void 0,
      chapterIndex: resume?.chapterIndex ?? void 0,
      segmentIndex: resume?.segmentIndex ?? void 0,
      segmentCount,
      chapterCount
    });
  }
  let storyBible = await buildStoryBible({ apiKey, title, bookType, genre, subgenre, tone, blueprint, outline });
  let rollingRecap = "";
  const chapters = extractChaptersFromOutline(outline).slice(0, chapterCount);
  const totalUnits = Math.max(1, chapters.length * (segmentCount * (1 + reviewPasses * 3) + 1) + 3);
  let completedUnits = 0;
  const progressFromUnits = () => Math.max(12, Math.min(99, 12 + Math.round(completedUnits / totalUnits * 86)));
  let lastSnapshotAt = 0;
  const snapshot = async (meta = null, force = false) => {
    const now = Date.now();
    if (!force && now - lastSnapshotAt < 5e3) return;
    lastSnapshotAt = now;
    await saveRunManuscriptSnapshot(runId, manuscript, meta);
  };
  if (!resumeEnabled) {
    manuscript = `# ${title}

`;
    manuscript += `TYPE: ${bookType.toUpperCase()}
`;
    manuscript += `GENRE: ${genre}${subgenre ? ` / ${subgenre}` : ""}
`;
    if (tone) manuscript += `TONE: ${tone}
`;
    manuscript += `TARGET WORDS: ${targetWords}
`;
    manuscript += `CHAPTERS: ${chapterCount}
`;
    manuscript += `
---

OUTLINE

${outline}

---

`;
    await snapshot({ agentId: "system", agentName: "System", stage: "outline", chapterCount, segmentCount, chapterIndex: 0, segmentIndex: 0 }, true);
  }
  const chapterReports = [];
  const resumeChapterIndex = resumeEnabled && Number.isFinite(Number(resume?.chapterIndex)) ? Number(resume.chapterIndex) : null;
  const resumeSegmentIndex = resumeEnabled && Number.isFinite(Number(resume?.segmentIndex)) ? Number(resume.segmentIndex) : null;
  const resumeStage = resumeEnabled && typeof resume?.stage === "string" ? String(resume.stage) : "";
  const resumeSegmentStart = resumeEnabled && Number.isFinite(Number(resume?.segmentStart)) ? Number(resume.segmentStart) : null;
  const resumeSegmentEnd = resumeEnabled && Number.isFinite(Number(resume?.segmentEnd)) ? Number(resume.segmentEnd) : null;
  for (let i = 0; i < chapters.length; i += 1) {
    if (await isCancelled()) return null;
    const ch = chapters[i];
    if (resumeChapterIndex != null && ch.index < resumeChapterIndex) continue;
    const heading = `Chapter ${ch.index}: ${ch.title}`;
    const chapterSections = [];
    const chapterNotes = [];
    const activeDirective = await getActiveRunDirective(runId);
    const directiveText = String(activeDirective?.text ?? "").trim();
    const directiveBlock = directiveText ? `USER DIRECTIVE (apply going forward):
${directiveText}

` : "";
    const continuityBlock = (directiveBlock + buildContinuityBlock({
      storyBible,
      recap: rollingRecap,
      chapterBeat: ch.beat || "",
      chapterLabel: heading
    })).trim();
    const segmentStartIndex = resumeChapterIndex === ch.index && resumeSegmentIndex != null ? resumeSegmentIndex : 0;
    for (let segmentIndex = segmentStartIndex; segmentIndex < segmentCount; segmentIndex += 1) {
      if (await isCancelled()) return null;
      const segmentLabel = `Part ${segmentIndex + 1}/${segmentCount}`;
      const isResumeSegment = resumeChapterIndex === ch.index && resumeSegmentIndex === segmentIndex && resumeEnabled;
      const segmentSuffix = `

`;
      let segmentStart = isResumeSegment && resumeSegmentStart != null ? resumeSegmentStart : null;
      let segmentEnd = isResumeSegment && resumeSegmentEnd != null ? resumeSegmentEnd : null;
      const chapterStart = manuscript.lastIndexOf(`## ${heading}`);
      const chapterStartSafe = chapterStart >= 0 ? chapterStart : Math.max(0, manuscript.length - 12e3);
      const priorContext = segmentStart != null ? manuscript.slice(Math.max(0, segmentStart - 4e3), segmentStart) : manuscript.slice(-4e3);
      const chapterSoFarText = segmentStart != null ? manuscript.slice(chapterStartSafe, segmentStart) : "";
      let segmentText = "";
      if (isResumeSegment && segmentStart != null && segmentEnd != null && segmentEnd > segmentStart) {
        segmentText = manuscript.slice(segmentStart, segmentEnd).replace(/\s+$/g, "").trim();
      }
      const shouldRedoDraft = !isResumeSegment || !segmentText || resumeStage === "draft";
      await push({
        type: "agent_event",
        runId,
        at: nowIso(),
        agentId: "writer",
        agentName: "Writer",
        stage: "draft",
        message: `Drafting ${heading} ${segmentLabel}`,
        progress: progressFromUnits(),
        chapterIndex: ch.index,
        segmentIndex,
        segmentCount,
        chapterCount
      });
      if (shouldRedoDraft) {
        segmentText = await openaiChat({
          apiKey,
          temperature: 0.78,
          maxTokens: 2200,
          messages: [
            {
              role: "system",
              content: `You are a professional novelist with a human voice.
Write scene-forward prose (action + dialogue + sensory detail) with subtext and distinct character voices.
PACING IS KING: keep paragraphs tight, keep the scene moving, and maintain micro-tension.
Structure: hook in the first 2 lines, rising tension, a clear turn, then end on a forward-moving hook.
Avoid: generic AI phrasing, moralizing, over-explaining, meta commentary, and summary tone.
Avoid: "suddenly", "as if", "in a world", "little did they know", "couldn't help but".
Prefer concrete verbs and specific images over abstractions. Vary sentence rhythm.
Do not reset character knowledge or relationships between segments.
Obey the provided CONTINUITY MEMORY block as canon.
Blueprint is CANON: only write events that belong inside the blueprint plan; do not invent new plot beats outside it.`
            },
            {
              role: "user",
              content: `${continuityBlock}

Write ${segmentLabel} of ${heading} for this book.
Book title: ${title}
Genre: ${genre}${subgenre ? ` / ${subgenre}` : ""}
Tone: ${tone || "default"}
Chapter beat: ${ch.beat || "Advance the book meaningfully and specifically."}
Target length for this part: about ${wordsPerSegment} words.
Previous book context:
${priorContext || "Beginning of the manuscript."}

Existing text for this chapter so far:
${chapterSoFarText.slice(-5e3) || "No prior chapter text yet."}

` + (blueprint ? `Blueprint (canonical plan - do NOT continue past it, do NOT add new beats):
${blueprint}

` : "") + `Pacing checklist (obey):
- every page must contain change (new info, reversal, decision, or escalating pressure)
- minimize exposition; embed context inside action/dialogue
- keep stakes present; use concrete sensory anchors

${segmentIndex === 0 ? `Start with "## ${heading}".` : "Continue directly from the previous paragraph with no repeated heading."} Do not summarize prior material. Add new substance through actions, dialogue, and sensory beats. End on a forward-moving hook.`
            }
          ]
        });
      }
      completedUnits += 1;
      segmentText = normalizeChapterSegment(segmentText, heading, segmentIndex === 0);
      if (segmentStart != null && segmentEnd != null && segmentEnd >= segmentStart) {
        manuscript = manuscript.slice(0, segmentStart) + `${segmentText}${segmentSuffix}` + manuscript.slice(segmentEnd);
        segmentEnd = segmentStart + `${segmentText}${segmentSuffix}`.length;
      } else {
        segmentStart = manuscript.length;
        manuscript += `${segmentText}${segmentSuffix}`;
        segmentEnd = manuscript.length;
      }
      chapterSections.push(segmentText);
      await snapshot(
        { agentId: "writer", agentName: "Writer", stage: "draft", chapterIndex: ch.index, segmentIndex, segmentCount, chapterCount, segmentStart, segmentEnd },
        true
      );
      const resumeSkipToReview = isResumeSegment && resumeStage && resumeStage !== "draft";
      for (let pass = 0; pass < reviewPasses; pass += 1) {
        if (await isCancelled()) return null;
        await push({
          type: "agent_event",
          runId,
          at: nowIso(),
          agentId: "reviewer",
          agentName: "Reviewer",
          stage: "review",
          message: `Reviewing ${heading} ${segmentLabel} (pass ${pass + 1}/${reviewPasses})`,
          progress: progressFromUnits(),
          chapterIndex: ch.index,
          segmentIndex,
          segmentCount,
          chapterCount
        });
        if (!resumeSkipToReview || resumeStage === "review" || resumeStage === "revise" || resumeStage === "qc") {
          await snapshot({ agentId: "reviewer", agentName: "Reviewer", stage: "review", chapterIndex: ch.index, segmentIndex, segmentCount, chapterCount, segmentStart, segmentEnd });
        }
        const review = await openaiChat({
          apiKey,
          temperature: 0.25,
          maxTokens: 900,
          messages: [
            { role: "system", content: "You are a rigorous developmental editor and line editor. Give concrete, specific notes. Prioritize depth, clarity, originality, and continuity." },
            {
              role: "user",
              content: `${continuityBlock}

Review this chapter segment.
Book: ${title}
Chapter: ${heading}
Chapter beat: ${ch.beat || "N/A"}
Segment target: about ${wordsPerSegment} words

Text:
${segmentText}

Return:
- 3 structural/content improvements
- 3 line-level improvements
- 2 continuity/QC checks`
            }
          ]
        });
        await push({
          type: "agent_event",
          runId,
          at: nowIso(),
          agentId: "reviewer",
          agentName: "Reviewer",
          stage: "review",
          message: `Review notes for ${heading} ${segmentLabel} (pass ${pass + 1}/${reviewPasses})`,
          progress: progressFromUnits(),
          chunk: review,
          chapterIndex: ch.index,
          segmentIndex,
          segmentCount,
          chapterCount
        });
        completedUnits += 1;
        chapterNotes.push(`## ${heading} ${segmentLabel} Review Pass ${pass + 1}
${review}`);
        await push({
          type: "agent_event",
          runId,
          at: nowIso(),
          agentId: "reviser",
          agentName: "Reviser",
          stage: "revise",
          message: `Applying review notes to ${heading} ${segmentLabel}`,
          progress: progressFromUnits(),
          chapterIndex: ch.index,
          segmentIndex,
          segmentCount,
          chapterCount
        });
        if (!resumeSkipToReview || resumeStage === "revise" || resumeStage === "qc") {
          await snapshot({ agentId: "reviser", agentName: "Reviser", stage: "revise", chapterIndex: ch.index, segmentIndex, segmentCount, chapterCount, segmentStart, segmentEnd });
        }
        const wordsBefore = countWords(segmentText);
        segmentText = await openaiChat({
          apiKey,
          temperature: 0.45,
          maxTokens: 2200,
          messages: [
            {
              role: "system",
              content: "You are a precise revising author and line editor.\nGoal: improve pacing, clarity, specificity, and voice while preserving continuity and intent.\nTighten sentences, remove filler, sharpen images, and make dialogue do work.\nObey the CONTINUITY MEMORY block as canon and obey the Blueprint (canonical plan).\nReturn only the revised prose."
            },
            {
              role: "user",
              content: `${continuityBlock}

Revise this chapter segment using the review notes.
Keep the segment at roughly ${wordsPerSegment} words.
${segmentIndex === 0 ? `Keep the heading as "## ${heading}".` : "Do not add or repeat a heading."}

Review notes:
${review}

Current segment:
${segmentText}`
            }
          ]
        });
        completedUnits += 1;
        segmentText = normalizeChapterSegment(segmentText, heading, segmentIndex === 0);
        const wordsAfter = countWords(segmentText);
        const wordDelta = wordsAfter - wordsBefore;
        manuscript = manuscript.slice(0, segmentStart) + `${segmentText}${segmentSuffix}` + manuscript.slice(segmentEnd);
        segmentEnd = segmentStart + `${segmentText}${segmentSuffix}`.length;
        chapterSections[segmentIndex] = segmentText;
        await snapshot({ agentId: "reviser", agentName: "Reviser", stage: "revise", chapterIndex: ch.index, segmentIndex, segmentCount, chapterCount, segmentStart, segmentEnd }, true);
        await push({
          type: "agent_event",
          runId,
          at: nowIso(),
          agentId: "reviser",
          agentName: "Reviser",
          stage: "revise",
          message: `Revision applied to ${heading} ${segmentLabel} (${wordDelta >= 0 ? "+" : ""}${wordDelta} words)`,
          progress: progressFromUnits(),
          wordDelta,
          chapterIndex: ch.index,
          segmentIndex,
          segmentCount,
          chapterCount
        });
        await snapshot({ agentId: "reviser", agentName: "Reviser", stage: "revise", chapterIndex: ch.index, segmentIndex, segmentCount, chapterCount, segmentStart, segmentEnd });
        const qc = await openaiChat({
          apiKey,
          temperature: 0.1,
          maxTokens: 500,
          messages: [
            { role: "system", content: "You are a strict QC editor. Check coherence, specificity, continuity, and whether the notes were actually addressed." },
            {
              role: "user",
              content: `${continuityBlock}

QC this revised chapter segment.
Return exactly:
Status: PASS or NEEDS_WORK
Issues:
- bullet list

Segment:
${segmentText}`
            }
          ]
        });
        await push({
          type: "agent_event",
          runId,
          at: nowIso(),
          agentId: "qc",
          agentName: "QC",
          stage: "qc",
          message: `QC notes for ${heading} ${segmentLabel} (pass ${pass + 1}/${reviewPasses})`,
          progress: progressFromUnits(),
          chunk: qc,
          chapterIndex: ch.index,
          segmentIndex,
          segmentCount,
          chapterCount
        });
        completedUnits += 1;
        chapterNotes.push(`## ${heading} ${segmentLabel} QC Pass ${pass + 1}
${qc}`);
      }
      await push({
        type: "agent_event",
        runId,
        at: nowIso(),
        agentId: "writer",
        agentName: "Writer",
        stage: "draft",
        message: `${heading} ${segmentLabel} complete`,
        progress: progressFromUnits(),
        chunk: segmentText,
        chapterIndex: ch.index,
        segmentIndex,
        segmentCount,
        chapterCount
      });
    }
    const chapterText = chapterSections.join("\n\n").trim();
    await push({
      type: "agent_event",
      runId,
      at: nowIso(),
      agentId: "qc",
      agentName: "QC",
      stage: "qc",
      message: `Final chapter QC for ${heading}`,
      progress: progressFromUnits(),
      chapterIndex: ch.index,
      segmentIndex: segmentCount,
      segmentCount,
      chapterCount
    });
    const chapterQc = await openaiChat({
      apiKey,
      temperature: 0.15,
      maxTokens: 700,
      messages: [
        { role: "system", content: "You are a senior manuscript reviewer. Evaluate whether the chapter is substantive, coherent, and aligned with its outline beat." },
        {
          role: "user",
          content: `${continuityBlock}

Review this completed chapter.
Chapter: ${heading}
Beat: ${ch.beat || "N/A"}
Target words: about ${wordsPerChapter}

Return:
- Verdict
- 5 strongest improvements made
- 5 remaining issues, if any

` + chapterText.slice(0, 18e3)
        }
      ]
    });
    await push({
      type: "agent_event",
      runId,
      at: nowIso(),
      agentId: "qc",
      agentName: "QC",
      stage: "qc",
      message: `Chapter QC notes for ${heading}`,
      progress: progressFromUnits(),
      chunk: chapterQc,
      chapterIndex: ch.index,
      segmentIndex: segmentCount,
      segmentCount,
      chapterCount
    });
    completedUnits += 1;
    chapterReports.push({ chapter: heading, words: countWords(chapterText), notes: chapterNotes.join("\n\n"), qc: chapterQc });
    const memoryUpdate = await updateStoryMemory({
      apiKey,
      title,
      storyBible,
      recap: rollingRecap,
      newText: chapterText,
      chapterLabel: heading
    });
    storyBible = memoryUpdate.storyBible;
    rollingRecap = memoryUpdate.recap;
    await snapshot({ agentId: "qc", agentName: "QC", stage: "qc", chapterIndex: ch.index, segmentIndex: segmentCount, segmentCount, chapterCount }, true);
  }
  if (await isCancelled()) return null;
  await push({
    type: "agent_event",
    runId,
    at: nowIso(),
    agentId: "editor",
    agentName: "Editor",
    stage: "edit",
    message: "Running final book review",
    progress: progressFromUnits()
  });
  await snapshot({ agentId: "editor", agentName: "Editor", stage: "edit", chapterIndex: chapterCount, segmentIndex: segmentCount, segmentCount, chapterCount });
  const manuscriptWordCount = countWords(manuscript);
  const polish = await openaiChat({
    apiKey,
    temperature: 0.3,
    maxTokens: 1200,
    messages: [
      { role: "system", content: "You are a senior book reviewer. Produce practical, high-signal editorial feedback for an almost-finished manuscript." },
      {
        role: "user",
        content: `This book currently has about ${manuscriptWordCount.toLocaleString()} words.
Provide:
- 8 macro improvements
- 8 line/style improvements
- 8 publish-readiness checks

Outline:
${outline.slice(0, 5e3)}

Opening excerpt:
${manuscript.slice(0, 8e3)}

Closing excerpt:
${manuscript.slice(-8e3)}`
      }
    ]
  });
  completedUnits += 1;
  const finalQc = await openaiChat({
    apiKey,
    temperature: 0.1,
    maxTokens: 700,
    messages: [
      { role: "system", content: "You are the final QC gate before publication. Be concise, skeptical, and concrete." },
      {
        role: "user",
        content: `Evaluate this manuscript for completion and quality.
Return:
Status: PASS or NEEDS_WORK
Reason:
- bullet list

Outline:
${outline.slice(0, 5e3)}

Manuscript opening:
${manuscript.slice(0, 7e3)}

Manuscript ending:
${manuscript.slice(-7e3)}`
      }
    ]
  });
  completedUnits += 1;
  await push({
    type: "agent_event",
    runId,
    at: nowIso(),
    agentId: "editor",
    agentName: "Editor",
    stage: "edit",
    message: "Final review complete",
    progress: progressFromUnits(),
    chunk: `${polish}

${finalQc}`
  });
  const projectId = import_node_crypto.default.randomUUID();
  const project = {
    id: projectId,
    title,
    createdAt: nowIso(),
    updatedAt: nowIso(),
    meta: {
      bookType,
      genre,
      subgenre,
      tone,
      lengthLabel,
      targetWords,
      chapterCount,
      wordsPerChapter,
      segmentCount,
      reviewPasses,
      actualWords: manuscriptWordCount,
      model: OPENAI_MODEL
    },
    outline,
    manuscript,
    polish,
    finalQc,
    chapterReports
  };
  await saveProjectRecord(project);
  await snapshot({ agentId: "system", agentName: "System", stage: "save", chapterIndex: chapterCount, segmentIndex: segmentCount, segmentCount, chapterCount }, true);
  await push({
    type: "agent_event",
    runId,
    at: nowIso(),
    agentId: "system",
    agentName: "System",
    stage: "save",
    message: `Saved project ${projectId}`,
    progress: 100
  });
  return { projectId };
}

// netlify/functions/run-generator-background.mjs
async function handler(event) {
  if (event?.blobs) {
    connectLambda(event);
  }
  let body = null;
  try {
    body = event?.body ? JSON.parse(event.body) : null;
  } catch {
    return { statusCode: 400, body: JSON.stringify({ ok: false, error: "invalid_json" }) };
  }
  const runId = String(body?.runId ?? "").trim();
  const payload = body?.payload ?? null;
  const resume = body?.resume ?? null;
  const openaiApiKey = String(body?.openaiApiKey ?? "").trim() || String(process.env.OPENAI_API_KEY ?? "").trim();
  if (!runId) {
    return { statusCode: 400, body: JSON.stringify({ ok: false, error: "missing_run_id" }) };
  }
  if (!openaiApiKey) {
    await appendRunEvent(runId, {
      type: "run_error",
      runId,
      message: "Missing OPENAI_API_KEY",
      stage: "config",
      progress: 0
    });
    return { statusCode: 200, body: JSON.stringify({ ok: true }) };
  }
  const push = async (evt) => {
    await appendRunEvent(runId, evt);
  };
  const isCancelled = async () => {
    const run = await getRunRecord(runId);
    return Boolean(run?.cancelled);
  };
  try {
    const result = await generateBookRun({
      runId,
      payload,
      apiKey: openaiApiKey,
      push,
      isCancelled,
      resume
    });
    if (await isCancelled()) {
      await appendRunEvent(runId, {
        type: "run_cancelled",
        runId,
        message: "Run cancelled"
      });
      return { statusCode: 200, body: JSON.stringify({ ok: true }) };
    }
    await appendRunEvent(runId, {
      type: "run_completed",
      runId,
      projectId: result?.projectId ?? null,
      progress: 100,
      stage: "save"
    });
  } catch (err) {
    await appendRunEvent(runId, {
      type: "run_error",
      runId,
      message: String(err?.message ?? err)
    });
  }
  return { statusCode: 200, body: JSON.stringify({ ok: true }) };
}
var config = {
  type: "experimental-background"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
